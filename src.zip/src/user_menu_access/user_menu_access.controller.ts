import { Controller } from '@nestjs/common';

@Controller('user-menu-access')
export class UserMenuAccessController {}

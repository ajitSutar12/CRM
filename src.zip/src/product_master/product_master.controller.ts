import { Controller } from '@nestjs/common';

@Controller('product-master')
export class ProductMasterController {}
